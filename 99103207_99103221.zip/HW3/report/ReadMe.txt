screenshots only contain new features of project
the deployment details is not mentioned but i mentioned some of them below
the login mechanism is deployed with 3 storage variables to check isLoggedIn, username, password if isLoggedIn is true the user has logged in successfuly
the mechanism of shopping cart is also deployed with an array in localstorage by adding index of shoeItem to this array or removing it
the mechanism of dynamic listViews for viewing shoeItems in pages: home, details and shopping cart is deployed by a template html string in javascript and adding them to childs of a single container

other deployments are tried to be fully described in code readabilty and comments

Thank You